import os,sys,json,subprocess,socket,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];logs=R/'data/logs';logs.mkdir(parents=True,exist_ok=True)
env={**os.environ,'PYTHONIOENCODING':'utf-8','NEXT_TELEMETRY_DISABLED':'1','NO_PROXY':'127.0.0.1,localhost','no_proxy':'127.0.0.1,localhost'}
node=Path('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
def listening(port):
    with socket.socket() as s:
        s.settimeout(.25);return s.connect_ex(('127.0.0.1',port))==0
def spawn(name,args,port=None):
    if port and listening(port):print(name+' already listening');return None
    with (logs/(name+'.log')).open('ab') as log:
        p=subprocess.Popen([str(x) for x in args],cwd=R,env=env,stdout=log,stderr=log,stdin=subprocess.DEVNULL,creationflags=flags)
    print(name+' started');return {'name':name,'pid':p.pid,'port':port}
subprocess.run([sys.executable,'-X','utf8',str(R/'scripts/init_local.py')],check=True,env=env,creationflags=flags)
state_file=R/'data/private/processes.json';states=json.loads(state_file.read_text()) if state_file.exists() else []
services=[('temporal',[R/'.runtime/temporal/temporal.exe','server','start-dev','--ip','127.0.0.1','--port','7239','--ui-port','8239','--db-filename',R/'data/temporal.db']),('api',[sys.executable,'-X','utf8','-m','uvicorn','backend.app:app','--host','127.0.0.1','--port','8010','--no-access-log']),('web',[node,R/'frontend/node_modules/next/dist/bin/next','start',R/'frontend','--hostname','127.0.0.1','--port','3010'])]
for name,args in services:
    port={'temporal':7239,'api':8010,'web':3010}[name];r=spawn(name,args,port)
    if r:states=[x for x in states if x['name']!=name]+[r]
    for _ in range(40):
        if listening(port):break
        time.sleep(.25)
    else:raise RuntimeError(name+' did not start; see data/logs/'+name+'.log')
# Worker is independently managed; check owned PID rather than a listening port.
old=next((s for s in states if s['name']=='worker'),None)
alive=False
if old:
    try:
        os.kill(old['pid'],0);alive=True
    except OSError:pass
if not alive:
    r=spawn('worker',[sys.executable,'-X','utf8','-m','backend.worker']);states=[x for x in states if x['name']!='worker']+[r]
state_file.write_text(json.dumps(states,indent=2))
print('Workbench: http://127.0.0.1:3010')
