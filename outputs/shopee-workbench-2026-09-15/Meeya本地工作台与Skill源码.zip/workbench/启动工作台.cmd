@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0启动工作台.ps1"
if errorlevel 1 pause
