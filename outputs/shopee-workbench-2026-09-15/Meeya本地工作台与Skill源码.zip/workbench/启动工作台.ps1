$ErrorActionPreference = 'Stop'
$taskRoot = $PSScriptRoot
& (Join-Path $taskRoot '.venv/Scripts/python.exe') -X utf8 (Join-Path $taskRoot 'scripts/start_local.py')
if ($LASTEXITCODE -ne 0) { throw '启动失败，请查看 workbench/data/logs 中的日志。' }
Start-Process 'http://127.0.0.1:3010'
